const Sequelize = require('sequelize')

const sequelize = new Sequelize('examen_DILJ','admin','Ja1mesda.',{
    dialect: 'mysql',
    host:'database-1.c5yh6twdnv7w.us-east-1.rds.amazonaws.com',
    define:{
        timestamps: false,
        freezeTableName: true
    }
})

const modelDefiners = [
    require('../models/equipo'),
    require('../models/edad'),
    require('../models/jugador'),
]

//Adherir los modelos al objeto de colección
for(const modelDefiner of modelDefiners){
    modelDefiner(sequelize);
}


module.exports = sequelize