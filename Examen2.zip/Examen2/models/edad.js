const Sequelize = require('sequelize');

const Edad = (sequelize) =>{
    sequelize.define('Edad',{
        numeroEdad: Sequelize.INTEGER,
    })
}

module.exports = Edad;