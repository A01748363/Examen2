const Sequelize = require('sequelize');

const Jugador = (sequelize) =>{
    sequelize.define('Jugador',{
        nombreJugador: Sequelize.STRING,
    })
}

module.exports = Jugador;