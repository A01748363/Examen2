const Sequelize = require('sequelize');

const Euquipo = (sequelize) =>{
    sequelize.define('Euquipo',{
        nombreEquipo: Sequelize.STRING,
    })
}

module.exports = Euquipo;