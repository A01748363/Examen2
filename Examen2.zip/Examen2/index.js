const express = require("express")
const sequelize = require('./utils/database')
const routesR = require('./routes/jugador')
const app = express();
app.use(express.json())

app.use('/jugador',routesR);

sequelize.sync()
    .then(
        app.listen(8080,()=>{
            console.log("Servidor online en el puerto 8080")
        })
    )
    .catch(err=>console.log(err))