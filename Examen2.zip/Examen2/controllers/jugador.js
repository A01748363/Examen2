const path = require("path")
const Jugador = require("../utils/database").models.Jugador;
const sequelize = require("../utils/database");
const Sequelize = require("sequelize");


exports.postAgregarJugador = (req,res)=>{
    console.log(req.body)
    Jugador.create(req.body)
        .then(ca=>{
            console.log("Registro Existoso")
            res.json({estado: "aceptado"})
        })
        .catch(err=>{
            console.log(err)
            res.json({estado: "error"})
        })
}

exports.getConsultaNombre = (req,res)=>{
    res.send('<h1>Datos de las consolas</h1>')
}