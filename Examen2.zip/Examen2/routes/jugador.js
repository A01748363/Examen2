const express = require('express');
const router = express.Router();
const jugadoresController = require('../controllers/jugador')

router.post('/agregarJugador',jugadoresController.postAgregarJugador)
router.get('/consultaNombre',jugadoresController.getConsultaNombre)

module.exports = router